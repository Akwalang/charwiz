use x11::xlib;
use x11::xkb;

pub fn get_current_keyboard_layout_id() -> String {
  unsafe {
    let display = xlib::XOpenDisplay(std::ptr::null());
    if display.is_null() {
      // семантически аналогично невозможности получить HWND
      return "00000000".to_string();
    }

    let mut state: xkb::XkbStateRec = std::mem::zeroed();
    let status = xkb::XkbGetState(
      display,
      xkb::XkbUseCoreKbd,
      &mut state,
    );

    xlib::XCloseDisplay(display);

    if status != xlib::Success {
      return "00000000".to_string();
    }

    let group = state.group;

    // Маппинг group → pseudo LANGID
    match group {
      0 => "00000409", // en_US
      1 => "00000419", // ru_RU
      _ => "00000000",
    }
    .to_string()
  }
}
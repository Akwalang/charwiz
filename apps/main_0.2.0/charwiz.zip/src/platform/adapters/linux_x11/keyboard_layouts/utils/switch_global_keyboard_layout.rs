use x11::xlib;
use x11::xkb;

pub fn switch_global_keyboard_layout(layout_code: &str) -> anyhow::Result<()> {
  unsafe {
    let display = xlib::XOpenDisplay(std::ptr::null());
    if display.is_null() {
      return Err(anyhow::anyhow!("Failed to open X display"));
    }

    // mapping LANGID → XKB group
    let target_group: u8 = match layout_code {
      "00000409" => 0, // en
      "00000419" => 1, // ru
      _ => {
        xlib::XCloseDisplay(display);
        return Err(anyhow::anyhow!(
          "Unknown keyboard layout code: {}",
          layout_code
        ));
      }
    };

    let status = xkb::XkbLockGroup(
      display,
      xkb::XkbUseCoreKbd,
      target_group.into(),
    );

    xlib::XFlush(display);
    xlib::XCloseDisplay(display);

    if status != xlib::Success {
      return Err(anyhow::anyhow!("XkbLockGroup failed"));
    }

    Ok(())
  }
}
use x11::xlib;
use x11::xkb;

use crate::platform::common::structs::KeyboardLayoutItem;
use crate::platform::common::utils;

use std::ffi::CStr;
use std::ptr;

const MAX_GROUPS: usize = 8;

pub fn get_keyboard_layouts() -> Vec<KeyboardLayoutItem> {
  unsafe {
    let display = xlib::XOpenDisplay(ptr::null());
    if display.is_null() {
      return vec![];
    }

    let mut desc = xkb::XkbAllocKeyboard();
    if desc.is_null() {
      xlib::XCloseDisplay(display);
      return vec![];
    }

    let status = xkb::XkbGetNames(
      display,
      xkb::XkbGroupNamesMask,
      desc,
    );

    if status != xlib::Success {
      xkb::XkbFreeKeyboard(desc, 0, 1);
      xlib::XCloseDisplay(display);
      return vec![];
    }

    let names = (*desc).names;
    let group_names = names.groups;

    let mut result = Vec::new();

    for i in 0..MAX_GROUPS {
      let atom = group_names[i];
      if atom == 0 {
        continue;
      }

      let atom_name = xlib::XGetAtomName(display, atom);
      if atom_name.is_null() {
        continue;
      }

      let symbol = CStr::from_ptr(atom_name)
        .to_string_lossy()
        .into_owned();

      xlib::XFree(atom_name as *mut _);

      // Маппинг symbol → pseudo LANGID
      let (layout_id, layout_name) = match symbol.as_str() {
        "us" => ("00000409", "en-US"),
        "ru" => ("00000419", "ru-RU"),
        _ => ("00000000", &symbol),
      };

      result.push(
        KeyboardLayoutItem::new(
          layout_id.to_string(),
          utils::normalize_language_name(layout_name.to_string()),
        )
      );
    }

    xkb::XkbFreeKeyboard(desc, 0, 1);
    xlib::XCloseDisplay(display);

    result
  }
}